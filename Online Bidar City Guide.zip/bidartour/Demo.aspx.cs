﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Demo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [System.Web.Services.WebMethod]
    [System.Web.Script.Services.ScriptMethod]
    public static AjaxControlToolkit.Slide[] GetSlides()
    {
        string store_folder = HttpContext.Current.Server.MapPath("~/Bidar");
        string[] collected_files = System.IO.Directory.GetFiles(store_folder);
        int i = 0;
        int br = collected_files.Length;
        AjaxControlToolkit.Slide[] slide = new AjaxControlToolkit.Slide[br];
        foreach (string file in collected_files)
        {
            slide[i] = new AjaxControlToolkit.Slide("Bidar/" +
            file.Substring(store_folder.Length + 1), file, i.ToString());
            i++;
        }
        return slide;
    }
}