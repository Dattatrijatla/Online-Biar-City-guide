﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Data.OracleClient;
using System.Windows;

public partial class query : System.Web.UI.Page
{
    OracleConnection con = new System.Data.OracleClient.OracleConnection("Data Source=xe; user ID=bidar; password=bidar; unicode=true");
    OracleCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        cmd = new System.Data.OracleClient.OracleCommand("insert into query values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text +  "')", con);
        cmd.ExecuteNonQuery();
        //Label3.Text = "done";
        Label1.Text = "Query submitted succesfuly";
        //Label1.Visible = true;
       // cmd.ExecuteNonQuery();
       // Response.Redirect("Loginpage.aspx");

    }
}