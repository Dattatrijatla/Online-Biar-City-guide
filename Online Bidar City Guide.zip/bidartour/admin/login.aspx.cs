﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.OracleClient;
using System.Windows.Forms;

public partial class login : System.Web.UI.Page
{
    OracleConnection con = new System.Data.OracleClient.OracleConnection("Data Source=xe; user ID=bidar; password=bidar; unicode=true");
    OracleCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        cmd = new System.Data.OracleClient.OracleCommand("Select * from adminlogin where username='" + TextBox1.Text + "'and Password='" + TextBox2.Text + "'", con);
        cmd.CommandType = CommandType.Text;
        OracleDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {

            TextBox1.Text = dr["username"].ToString();
            TextBox2.Text = dr["password"].ToString();
            Response.Redirect("~/admin/Home.aspx");
            con.Dispose();
        }
        else
        {
            MessageBox.Show("wrong username and password");


            Label1.Text = "Wrong user and password";
            Label1.Visible = true;
        }

    }
}