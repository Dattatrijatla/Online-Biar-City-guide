﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.OracleClient;
using System.Windows;
using System.Windows.Forms;

public partial class admin_tourist : System.Web.UI.Page
{
    OracleConnection con = new System.Data.OracleClient.OracleConnection("Data Source=xe; user ID=bidar; password=bidar; unicode=true");
    OracleCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         cmd = new System.Data.OracleClient.OracleCommand("insert into guide values('" + TextBox1.Text + "','" + TextBox2.Text + "','"+TextBox3.Text+"','" + TextBox4.Text + "','" + TextBox5.Text + "')", con);
          cmd.ExecuteNonQuery();
        MessageBox.Show("Successfully Registered");
        // Label5.Text = "Successfully Registered";
        // Label5.Visible = true;

        con.Dispose();
    
    }
}