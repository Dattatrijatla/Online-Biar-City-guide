﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Data.OracleClient;
using System.Windows;

public partial class regpage : System.Web.UI.Page
{
     OracleConnection con = new System.Data.OracleClient.OracleConnection("Data Source=xe; user ID=bidar; password=bidar; unicode=true");
    OracleCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
             con.Open();
    }
    
  

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (TextBox1.Text == "" || TextBox2.Text == "")
        {
            Label3.Text = "wrong username and password";

            Label1.Text = "Missing Fields";
            Label1.Visible = true;
        }
        else
        {
            cmd = new System.Data.OracleClient.OracleCommand("insert into register values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + RadioButtonList1.SelectedItem.ToString() + "','" + TextBox4.Text + "','" + DropDownList1.SelectedItem.ToString() + "','" + TextBox5.Text + "','" + TextBox6.Text + "')", con);
            cmd.ExecuteNonQuery();
            Label3.Text = "done";
            Label1.Text = "Registeration Done";
            Label1.Visible = true;
            cmd = new System.Data.OracleClient.OracleCommand("insert into login values('" + TextBox1.Text + "','" + TextBox2.Text + "')", con);
            cmd.ExecuteNonQuery();
            Response.Redirect("login.aspx");
        }
        con.Dispose();

    }
}

    